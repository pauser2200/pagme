export const environment = {
  production: true,
  apiUrl: 'https://pagme-97cr.onrender.com/pagme'
};