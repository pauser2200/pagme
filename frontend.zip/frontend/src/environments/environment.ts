export const environment = {
  production: false,
  apiUrl: 'http://127.1.1.1:8000/pagme'
};