import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  AutoResume,
  DEFAULT_INTERRUPTSOURCES,
  DocumentInterruptSource,
  EventTargetInterruptSource,
  Idle,
  IdleExpiry,
  InterruptArgs,
  InterruptSource,
  KeepaliveSvc,
  LocalStorage,
  LocalStorageExpiry,
  NgIdleModule,
  SimpleExpiry,
  StorageInterruptSource,
  WindowInterruptSource,
  createDefaultInterruptSources,
  provideNgIdle
} from "./chunk-BL5D7ENA.js";
import "./chunk-5NKROQBM.js";
import "./chunk-YQZF7T32.js";
import "./chunk-7MGOZNC6.js";
import "./chunk-WGRCPX6P.js";
import "./chunk-YHCV7DAQ.js";
export {
  AutoResume,
  DEFAULT_INTERRUPTSOURCES,
  DocumentInterruptSource,
  EventTargetInterruptSource,
  Idle,
  IdleExpiry,
  InterruptArgs,
  InterruptSource,
  KeepaliveSvc,
  LocalStorage,
  LocalStorageExpiry,
  NgIdleModule,
  SimpleExpiry,
  StorageInterruptSource,
  WindowInterruptSource,
  createDefaultInterruptSources,
  provideNgIdle
};
